from .wrapped import PyKrovetzStemmer
